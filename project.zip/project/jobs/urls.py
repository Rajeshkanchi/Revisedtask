from django.contrib import admin
from django.urls import path
from.import views
from jobs.views import home_view, signup_view


urlpatterns = [
    path('', views.home,name='home'),
    path('workfromhome',views.workfromhome,name='workfromhome'),
    path('contact',views.contact,name='contact'),
    path('home',views.home,name='home'),
    path('about',views.about,name='about'),
    path('apply',views.apply,name='apply'),
    path('login',views.Candidate,name='login'),
    path('', home_view, name="home"),
    path('signup/', signup_view, name="signup")

]
